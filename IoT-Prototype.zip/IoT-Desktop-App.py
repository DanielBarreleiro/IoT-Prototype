with open('IoT-Data.csv', 'r') as input_file:
    for line in input_file:
        print(line)